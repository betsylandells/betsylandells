from random import randint
import matplotlib
matplotlib.use('TKAgg')
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import sys
import math
import random
import numpy as np

(lx,ly) = map(int, input('lx ly: ').split())


nstep = 10000
#blue susceptibile
#green infected
#red recovered
I=1
R=2
S=0

#make the initial grid randomly from 0,1,2s
def make_grid():
    # spin a matrix of 50x50 zeros
    grid=np.zeros((lx,ly),dtype=float)
    # initialise population randomly - people are either infected (1), susceptibile (2) or recovered (0)
    #initial grid has uniform probability 33% chance of each system
    for i in range(lx):
        for j in range(ly):
            #picks a number, 0, 1 or 2, with equal probability
            state = np.random.choice(a=3, p=[0.33, 0.33, 0.34])
            grid[i,j] = state
    return grid

#get error bars for variance using Jacknife method
def error_Var(I,p):
    avg_I = []
    variance = []
    for i in range(len(I)):
        #delete the ith element each time
        a = np.delete(I,i)
        #calculate heat capacity c_i
        mean_I = np.mean(a)
        avg_I.append(mean_I)
        square_I = np.square(np.array(a))
        variance.append((np.mean(square_I) - mean_I**2)/(lx*ly))
    x=0
    # sum of (c_i - c)^2
    for j in range(len(I)):
        x +=(variance[j]-np.mean(variance))**2
    return np.sqrt(x)

def SIRS_RULES(i,j,grid, p1, p2, p3):
    r=random.random()
    nn1 = grid[i,(j+1)%ly]
    nn2 = grid[(i+1)%lx,j]
    nn3 = grid[(i-1)%lx,j]
    nn4 = grid[i,(j-1)%ly]
    #S becomes I with probability p1, if at least 1 NN is infected
    if grid[i,j] == S:
        if nn1 == I or nn2 == I or nn3 == I or nn4 == I:
            if(r<=p1):
                grid[i,j] = I
    #infected site I becomes recovered (R) with probability p2
    elif grid[i,j] == I:
        if (r<= p2):
            grid[i,j] = R
    elif grid[i,j] == R:
        if (r<=p3):
            grid[i,j] = S
    return grid[i,j]

p2 = 0.5
p3 = 0.5
p1_list = np.arange(0.2,0.5,0.01)
mean_infection = []
var = []
variance = []
inf_sites = []

for p1 in p1_list:
    grid = make_grid()
    #main
    infected_sites_list = []
    inf_squared_list = []
    for n in range(nstep):
        for i in range(lx):
            for j in range(ly):
                #select spin randomly for particle 1 at (i,j)
                select_i=np.random.randint(0,lx)
                select_j=np.random.randint(0,ly)
                #apply SIRS rules
                grid[select_i,select_j] = SIRS_RULES(select_i,select_j,grid,p1,p2,p3)

        if (n>100):
            print(np.count_nonzero(grid==1))
            infected_sites_list.append(np.count_nonzero(grid==1))
            inf_squared_list.append(np.count_nonzero(grid==1)**2)
        #print(infected_sites_list)
    mean = np.mean(infected_sites_list)
    mean_infection.append(mean/(lx*ly))
    var.append((np.mean(inf_squared_list) - mean**2)/(lx*ly))
    print(mean_infection)
    print(var)
    print(variance)
#get energies to calculate errors
    inf_sites.append(infected_sites_list)
    mean_I = np.mean(infected_sites_list)
    square_I = np.square(np.array(infected_sites_list))
    variance.append((np.mean(square_I) - mean_I**2)/(lx*ly))

#calculate errors for each p
err_bars_V = []
for i in range(len(inf_sites)):
    err_bars_V.append(error_Var(inf_sites[i],p1_list[i]))



plt.plot(p1_list,var,'.')
plt.show()

plt.errorbar(p1_list,variance,yerr=err_bars_V)
plt.xlabel('Time')
plt.ylabel('Heat Capacity')
plt.savefig('heatcapacity.png')
plt.show()

np.savetxt('SIRS_mean_cut.csv', (mean_infection), delimiter=',')
np.savetxt('SIRS_var_cut.csv', (var), delimiter=',')

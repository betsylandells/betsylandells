import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import argparse
import random
import csv

ON = 1
OFF = 0

N = 50
nstep = 1000

IC = input("Initial condition (random/glider/blinker): ")

 # grid: a matrix of 50x50 zeros
def random_grid(N):
    grid=np.zeros((N,N),dtype=float)
    """creates a 50x50 grid of 0s and 1s"""
    # populate grid with random on/off -
    # more off than on
    for i in range(N):
        for j in range(N):
            r=random.random()
            if(r<0.2): grid[i,j]= ON
            if(r>=0.8): grid[i,j]= OFF
    return grid

def addGlider(i, j, grid):

    """adds a glider with top left cell at (i, j)"""
    glider = np.array([[0,  1, 0],
                       [0,  0, 1],
                       [1,  1, 1]])
    grid[i:i+3, j:j+3] = glider

def addBlinker(i, j, grid):

    """adds a blinker with top left cell at (i, j)"""
    blinker = np.array([[0,  1, 0],
                        [0,  1, 0],
                        [0,  1, 0]])
    grid[i:i+3, j:j+3] = blinker

def update(frameNum, img, grid, N): #framenNum

    # copy grid since we require 8 neighbors
    # for calculation and we go line by line
    newGrid = grid.copy()
    for i in range(N):
        for j in range(N):

            # compute 8-neighbor sum
            total = int((grid[i, (j-1)%N] + grid[i, (j+1)%N] +
                         grid[(i-1)%N, j] + grid[(i+1)%N, j] +
                         grid[(i-1)%N, (j-1)%N] + grid[(i-1)%N, (j+1)%N] +
                         grid[(i+1)%N, (j-1)%N] + grid[(i+1)%N, (j+1)%N]))

            # apply Conway's rules
            #If a cell is ON and has less than 2, more than 3 it turns OFF
            #if cell is ON and has exactly 2 it remains ON
            if grid[i, j]  == 1:
                if (total < 2) or (total > 3):
                    newGrid[i, j] = 0
            #If a cell is OFF and has three neighbors that are ON, it turns ON
            #If a cell is ON and has three neighbours ON it remains ON
            else:
                if total == 3:
                    newGrid[i, j] = 1

    # update data
    img.set_data(newGrid)
    grid[:] = newGrid[:]
    return img,

#main code
N = 50
updateInterval = 50
grid = np.array([])

# check if user picks Initial Conditon: "glider"
if IC == 'glider': #args.glider:
    grid = np.zeros(N*N).reshape(N, N)
    #centre of 3x3 square is at (1,1)
    addGlider(25, 25, grid)
# check if user picks Initial Conditon: "blinker"
elif IC == 'blinker': #args.blinker:
    grid = np.zeros(N*N).reshape(N, N)
    #centre of 3x3 square is at (1,1)
    addBlinker(25, 25, grid)

elif IC == 'random':
    grid = random_grid(N)

#count the number of active sites as a function of time
total_sites = []
for m in range(100):
    active_sites = []
    grid = np.array([])
    grid = random_grid(N)
    for n in range(5100):
        newgrid = grid.copy()
        for i in range(N):
            for j in range(N):

                # compute 8-neighbor sum
                total = int((grid[i, (j-1)%N] + grid[i, (j+1)%N] +
                             grid[(i-1)%N, j] + grid[(i+1)%N, j] +
                             grid[(i-1)%N, (j-1)%N] + grid[(i-1)%N, (j+1)%N] +
                             grid[(i+1)%N, (j-1)%N] + grid[(i+1)%N, (j+1)%N]))

                # apply Conway's rules
                #If a cell is ON and has less than 2, more than 3 it turns OFF
                #if cell is ON and has exactly 2 it remains ON
                if grid[i, j]  == 1:
                    if (total < 2) or (total > 3):
                        newgrid[i, j] = 0
                #If a cell is OFF and has three neighbors that are ON, it turns ON
                #If a cell is ON and has three neighbours ON it remains ON
                else:
                    if total == 3:
                        newgrid[i, j] = 1
        if n>100:
            # take a measurement after every ten sweeps
            if n%50 == 0:
                active_sites.append(sum(sum(newgrid)))
                print(sum(sum(newgrid)))
                #if len(active_sites) >= 10:
                    #if site_no in active_sites: #stops changing
                        #break

        grid[:] = newgrid[:]
    total_sites.append(active_sites)
print(total_sites)

np.savetxt('data7.csv', (total_sites), delimiter=',')
time_to_stop = []
count = 5 #no. of consecutive digits before deciding iteration has stopped
#running simulation 10 times
for i in range(100):
    #row of 50 values of sum of the grid
    for j in range(50-(count)):
        #if last 10 values are the same, consider system to have reached steady state and record time at which that occured
        if total_sites[i,j+5] ==  total_sites[i,j+4] == total_sites[i,j+3] == total_sites[i,j+2] == total_sites[i,j+1] == total_sites[i,j]:
            time = j
            break
        else:
            time = 0
    time_to_stop.append(time)

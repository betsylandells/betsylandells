from random import randint
import matplotlib
matplotlib.use('TKAgg')
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import sys
import math
import random
import numpy as np

(lx,ly) = map(int, input('lx ly: ').split())

(p1,p2,p3) = map(float, input('p1 p2 p3: ').split())

nstep = 1000

#blue susceptibile
#green infected
#red recovered
I=1
R=2
S=0

#make the initial grid randomly from 0,1,2s
def make_grid():
    # spin a matrix of 50x50 zeros
    grid=np.zeros((lx,ly),dtype=float)
    # initialise population randomly - people are either infected (1), susceptibile (2) or recovered (0)
    #initial grid has uniform probability 33% chance of each system
    for i in range(lx):
        for j in range(ly):
            #picks a number, 0, 1 or 2, with equal probability
            state = np.random.choice(a=3, p=[0.33, 0.33, 0.34])
            grid[i,j] = state
    return grid



def SIRS_RULES(i,j,grid):
    r=random.random()
    nn1 = grid[i,(j+1)%ly]
    nn2 = grid[(i+1)%lx,j]
    nn3 = grid[(i-1)%lx,j]
    nn4 = grid[i,(j-1)%ly]
    #S becomes I with probability p1, if at least 1 NN is infected with probability p1
    if grid[i,j] == S:
        if nn1 == I or nn2 == I or nn3 == I or nn4 == I:
            if(r<=p1):
                grid[i,j] = I
    #infected site I becomes recovered (R) with probability p2
    elif grid[i,j] == I:
        if (r<= p2):
            grid[i,j] = R
    elif grid[i,j] == R:
        if (r<=p3):
            grid[i,j] = S
    return grid[i,j]

grid = make_grid()

#main
infected_sites_list = []
for n in range(nstep):
    for i in range(lx):
        for j in range(ly):
            #select spin randomly for particle 1 at (i,j)
            select_i=np.random.randint(0,lx)
            select_j=np.random.randint(0,ly)
            #apply SIRS rules
            grid[select_i,select_j] = SIRS_RULES(select_i,select_j,grid)

    if (n%10 ==0):
        print(np.count_nonzero(grid==1))
        infected_sites_list.append(np.count_nonzero(grid==1))
        print(infected_sites_list)
        im=plt.imshow(grid, cmap = 'jet', animated=True, vmin = 0, vmax = 2)
        plt.draw()
        plt.pause(0.0001)

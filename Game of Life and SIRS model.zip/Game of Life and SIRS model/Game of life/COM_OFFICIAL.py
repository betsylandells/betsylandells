import numpy as np
import matplotlib.pyplot as plt
import random
import csv

ON = 1
OFF = 0

N = 50
nstep = 10000

IC = input("Initial condition (random/glider/blinker): ")

 # grid: a matrix of 50x50 zeros
def random_grid(N):
    grid=np.zeros((N,N),dtype=float)
    """creates a 50x50 grid of 0s and 1s"""
    # populate grid with random on/off -
    # more off than on
    for i in range(N):
        for j in range(N):
            r=random.random()
            if(r<0.2): grid[i,j]= ON
            if(r>=0.8): grid[i,j]= OFF
    return grid

def addGlider(i, j, grid):

    """adds a glider with top left cell at (i, j)"""
    glider = np.array([[0,  1, 0],
                       [0,  0, 1],
                       [1,  1, 1]])
    grid[i:i+3, j:j+3] = glider

def addBlinker(i, j, grid):

    """adds a blinker with top left cell at (i, j)"""
    blinker = np.array([[0,  1, 0],
                        [0,  1, 0],
                        [0,  1, 0]])
    grid[i:i+3, j:j+3] = blinker

#main code
N = 50
grid = np.array([])

# check if user picks Initial Conditon: "glider"
if IC == 'glider': #args.glider:
    grid = np.zeros(N*N).reshape(N, N)
    #centre of 3x3 square is at (1,1)
    addGlider(25, 25, grid)
# check if user picks Initial Conditon: "blinker"
elif IC == 'blinker': #args.blinker:
    grid = np.zeros(N*N).reshape(N, N)
    #centre of 3x3 square is at (1,1)
    addBlinker(25, 25, grid)

elif IC == 'random':
    grid = random_grid(N)


COM = []
grid = np.zeros(N*N).reshape(N, N)
addGlider(25, 25, grid)
newgrid = grid.copy()
for n in range(500):
    for i in range(N):
        for j in range(N):
            # compute 8-neighbor sum
            total = int((grid[i, (j-1)%N] + grid[i, (j+1)%N] +
                         grid[(i-1)%N, j] + grid[(i+1)%N, j] +
                         grid[(i-1)%N, (j-1)%N] + grid[(i-1)%N, (j+1)%N] +
                         grid[(i+1)%N, (j-1)%N] + grid[(i+1)%N, (j+1)%N]))

            # apply Conway's rules
            #If a cell is ON and has less than 2, more than 3 it turns OFF
            #if cell is ON and has exactly 2 it remains ON
            if grid[i, j]  == 1:
                if (total < 2) or (total > 3):
                    newgrid[i, j] = 0
            #If a cell is OFF and has three neighbors that are ON, it turns ON
            #If a cell is ON and has three neighbours ON it remains ON
            else:
                if total == 3:
                    newgrid[i, j] = 1
    COM.append(sum(newgrid))
    grid[:] = newgrid[:]
print(COM)

np.savetxt('COM.csv', (COM), delimiter=',')

pos = []
for i in range(len(COM)):
    pos.append(np.argmax(COM[i]))

x = np.arange(0,500)

from scipy.stats import linregress
print(linregress(x[95:290], pos[95:290]))

plt.scatter(x,pos,marker='+',label='speed: 0.25 points/frame')
plt.xlabel('time (frames)')
plt.ylabel('position in the lattice')
plt.legend()
plt.xlim([91,290])
plt.show()

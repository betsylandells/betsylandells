from random import randint
import matplotlib
matplotlib.use('TKAgg')
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import sys
import math
import random
import numpy as np

# define parameters
J = 1
kb = 1
nstep=10000

# define grid for input
lx = 50
ly = 50

#get method from user
method = input("Enter dynamics: ")

# spin a matrix of 50x50 zeros
spin=np.zeros((lx,ly),dtype=float)
# initialise spins randomly - spins are either +1 or -1
for i in range(lx):
    for j in range(ly):
        r=random.random()
        if(r<0.5): spin[i,j]=-1
        if(r>=0.5): spin[i,j]=1


# compute delta E = 2*J*[sum of nearest neighbours]
def deltaE(particle, i,j):
    #account for periodic BC by using the remainder function ie 51 maps to => 1 (51/50 = 1 remainder)
    nn1 = particle[i,j] * particle[i,(j+1)%ly]
    nn2 = particle[i,j] * particle[(i+1)%lx,j]
    nn3 = particle[i,j] * particle[(i-1)%lx,j]
    nn4 = particle[i,j] * particle[i,(j-1)%ly]
    E = 2 * (J * (nn1+nn2+nn3+nn4))
    return E


# perform metropolis test
def metropolis(dE):
    # if energy change is favourable (i.e. dE<0) flip the spin
    if dE<0:
        return True #spin flips
    else:
        #if energy change is not <0, the probability of the spin flip depends on fermi-dirac statistics
        p = min(1, np.exp(-dE/(kb*T)))
        rand = np.random.uniform(0,1)
        if rand<=p:
            #if p is greater than (or equal to) the thermal probability, flip it
            return True #spin flips
        else:
            return False #spin does not flip


# Glauber dynamics - pick one spin and get energy change
def Glauber():
    return deltaE(spin, itrial, jtrial)

#start glauber as all spin up
if method == 'Glauber':
    for i in range(lx):
        for j in range(ly):
            spin[i,j]=1

#start kawasaki as half spin up half spin down
if method == 'Kawasaki':
    spin1=np.ones((lx,int(ly/2)))
    spin2=-1*np.ones((lx,int(ly/2)))
    spin=np.concatenate((spin1,spin2),axis=1)


# Kawasaki dynamics
def Kawasaki():
  # calculate dE for each spin
  change1 = deltaE(spin, itrial, jtrial)
  change2 = deltaE(spin, ktrial, ltrial)
  # if nearest neighbours
  if [ktrial,ltrial] in [[(itrial+1)%lx,jtrial], [(itrial-1)%lx,jtrial],  [itrial,(jtrial+1)%ly], [itrial,(jtrial-1)%ly]]:
      # account for the 4J difference if nearest neighbours
      return (change1 + change2 + 4*J)
  # if not nearest neighbours
  else:
      # return dE as sum of energy changes
      return (change1 + change2)

#get magnetisation as sum of spins
def Magnetisation():
    M = np.sum(spin)
    return M

#calculate energy once at the beginning
def InitialEnergy():
    E = 0
    for i in range(lx):
        for j in range(ly):
            nn1 = spin[i,j] * spin[i,(j+1)%ly]
            nn2 = spin[i,j] * spin[(i+1)%lx,j]
            nn3 = spin[i,j] * spin[(i-1)%lx,j]
            nn4 = spin[i,j] * spin[i,(j-1)%ly]
            E += (nn1+nn2+nn3+nn4)
    #divide by two to account for double counting
    return -J * E/2

#get error bars for magnetisation using Jacknife method
def error_M(e1,T):
    avg_e = []
    susceptibility = []
    for i in range(len(e1)):
        #delete the ith element each time
        a = np.delete(e1,i)
        mean_M = np.mean(a)
        square_M = np.square(np.array(a))
        susceptibility.append(1/(lx*ly*kb*T) * (np.mean(square_M) - mean_M**2))
    x=0
    # sum of (m_i - m)^2
    for j in range(len(e1)):
        x +=(susceptibility[j]-np.mean(susceptibility))**2
    return np.sqrt(x)

#get error bars for heat capacity using Jacknife method
def error_C(e1,T):
    avg_e = []
    heatcapacity = []
    for i in range(len(e1)):
        #delete the ith element each time
        a = np.delete(e1,i)
        #calculate heat capacity c_i
        mean_E = np.mean(a)
        avg_e.append(mean_E)
        square_E = np.square(np.array(a))
        heatcapacity.append(1/(lx*ly*kb*T**2) * (np.mean(square_E) - mean_E**2))
    x=0
    # sum of (c_i - c)^2
    for j in range(len(e1)):
        x +=(heatcapacity[j]-np.mean(heatcapacity))**2
    return np.sqrt(x)

def get_errors_C(energies, Ts):
    err_bars = []
    for i in range(len(energies)):
        err_bars.append(error_C(energies[i],Ts[i]))
    return err_bars

def get_errors_M(magnetisations, Ts):
    err_bars = []
    for i in range(len(magnetisations)):
        err_bars.append(error_C(magnetisations[i],Ts[i]))
    return err_bars

# for each T do 10000 sweeps so run this loop for each T
Ts = np.arange(1,3,0.1)

#initialise empty lists
mag_series = []
eng_series = []
susceptibility = []
heatcapacity = []
avg_E_list = []
avg_M_list = []
energies = []
magnetisations = []

### body of the code to be run in the terminal ###

# sweeps over each position in 50x50 lattice n times (10000 times)
for T in Ts:
    mag_series = []
    eng_series = []
    initial_energy = InitialEnergy()
    totalenergychange = 0
    for n in range(nstep):
        for i in range(lx):
            for j in range(ly):

                #select spin randomly for particle 1 at (i,j)
                itrial=np.random.randint(0,lx)
                jtrial=np.random.randint(0,ly)

                if method == 'Kawasaki':
                    #select spin randomly for particle 2 at (k,l)
                    ktrial=np.random.randint(0,lx)
                    ltrial=np.random.randint(0,ly)
                    # if spin of i,j does not equal k,l then do not enter loop (swapping identical spins will not affect energy)
                    #if spin[itrial,jtrial] == spin[ktrial,ltrial]:
                        #continue
                    # get energy change from Kawasaki dynamics
                    energy_change = Kawasaki()
                    # if the metropolis algorithm gives True: flip the spin
                    if metropolis(energy_change):
                        spin[itrial, jtrial] *= -1
                        spin[ktrial, ltrial] *= -1
                        #if it flips, add on the energy change
                        totalenergychange += energy_change


                if method == 'Glauber':
                    #get energy change from glauber dynamics
                    energy_change = Glauber()
                    #if energy change is favourable then flip the energy
                    if metropolis(energy_change):
                        spin[itrial, jtrial] *= -1
                        #if it flips, add on the energy change
                        totalenergychange += energy_change

        # after 100 sweeps, take Magnetisation calculations
        if n>100:
            # take a measurement after every ten sweeps (1000 measurements per T total)
            if n%10 == 0:
                mag_series.append(abs(Magnetisation()))
                #energy is the initial energy of the matrix plus the total energy change
                eng_series.append(initial_energy + totalenergychange)

    #get magnetisations to calculate errors
    magnetisations.append(mag_series)
    #mean of magnetisations
    mean_M = np.mean(mag_series)
    avg_M_list.append(mean_M)
    #square of magnetisations
    square_M = np.square(np.array(mag_series))
    #calculate susceptibility for each T

    """susceptibility uses the magnetisation not the absolute magnetisation so next time dont use abs() for this part,
    create a new list of just Magnetisation()"""
    susceptibility.append(1/(lx*ly*kb*T) * (np.mean(square_M) - mean_M**2))

    #get energies to calculate errors
    energies.append(eng_series)
    #mean of energies
    mean_E = np.mean(eng_series)
    avg_E_list.append(mean_E)
    #square of energies
    square_E = np.square(np.array(eng_series))
    #get heat capacity for each T
    heatcapacity.append(1/(lx*ly*kb*T**2) * (np.mean(square_E) - mean_E**2))

#calculate errors for each T
err_bars_C = []
for i in range(len(energies)):
    err_bars_C.append(error_C(energies[i],Ts[i]))

err_bars_M = []
for i in range(20):
    err_bars_M.append(error_M(magnetisations[i],Ts[i]))

    print(susceptibility)
    print(heatcapacity)
    print(err_bars_C)
    print(avg_E_list)
    print(avg_M_list)
    print(err_bars_M)

plt.plot(Ts,susceptibility)
plt.xlabel('Time')
plt.ylabel('Susceptibility')
plt.savefig('susceptibility.png')
plt.show()

plt.errorbar(Ts,heatcapacity,yerr=err_bars_C)
plt.xlabel('Time')
plt.ylabel('Heat Capacity')
plt.savefig('heatcapacity.png')
plt.show()

plt.plot(Ts,avg_E_list)
plt.xlabel('Time')
plt.ylabel('<E>')
plt.savefig('energy.png')
plt.show()

plt.plot(Ts,avg_M_list)
plt.xlabel('Time')
plt.ylabel('<|M|>')
plt.savefig('magnetisation.png')
plt.show()

fig, axs = plt.subplots(2, 2)
axs[0, 0].plot(Ts,avg_E_list)
axs[0, 0].set_title('Average Energy vs time')
axs[0, 1].plot(Ts,avg_M_list, 'tab:orange')
axs[0, 1].set_title('Average magnetisation vs time')
axs[1, 0].plot(Ts,susceptibility, 'tab:green')
axs[1, 0].set_title('Susceptibility vs time')
axs[1, 1].plot(Ts,heatcapacity, 'tab:red')
axs[1, 1].set_title('Heat Capacity vs time')

plt.show()

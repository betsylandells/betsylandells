from random import randint
import matplotlib
matplotlib.use('TKAgg')
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import sys
import math
import random
import numpy as np

T = int(input("Enter temperature: "))

# define parameters
J = 1
kb = 1
nstep=10000

# define grid for input
lx = int(input('enter x dimension: '))
ly = int(input('enter y dimension: '))

# spin a matrix of 50x50 zeros
spin=np.zeros((lx,ly),dtype=float)

# initialise spins randomly - spins are either +1 or -1
for i in range(lx):
    for j in range(ly):
        r=random.random()
        if(r<0.5): spin[i,j]=-1
        if(r>=0.5): spin[i,j]=1

method = input("Enter dynamics: ")

# compute delta E = 2*J*[sum of nearest neighbours]
def deltaE(particle, i,j):
    #account for periodic BC by using the remainder function ie 51 maps to => 1 (51/50 = 1 remainder)
    nn1 = particle[i,j] * particle[i,(j+1)%ly]
    nn2 = particle[i,j] * particle[(i+1)%lx,j]
    nn3 = particle[i,j] * particle[(i-1)%lx,j]
    nn4 = particle[i,j] * particle[i,(j-1)%ly]
    E = 2 * (J * (nn1+nn2+nn3+nn4))
    return E

if method == 'Kawasaki':
    spin1=np.ones((lx,int(ly/2)))
    spin2=-np.ones((lx,int(ly/2)))
    spin = np.concatenate((spin1,spin2),axis=1)

# perform metropolis test
def metropolis(dE):
    # if energy change is favourable (i.e. dE<0) flip the spin
    if dE<0:
        return True #spin flips
    else:
        #if energy change is not <0, the probability of the spin flip depends on fermi-dirac statistics
        p = min(1, np.exp(-dE/(kb*T)))
        rand = np.random.uniform(0,1)
        if rand<=p:
            #if p is greater than (or equal to) the thermal probability, flip it
            return True #spin flips
        else:
            return False #spin does not flip


# Glauber dynamics - pick one spin and get energy change
def Glauber():
    return deltaE(spin, itrial, jtrial)


# Kawasaki dynamics
def Kawasaki():
  # calculate dE for each spin
  change1 = deltaE(spin, itrial, jtrial)
  change2 = deltaE(spin, ktrial, ltrial)
  # if nearest neighbours
  if [ktrial,ltrial] in [[(itrial+1)%lx,jtrial], [(itrial-1)%lx,jtrial],  [itrial,(jtrial+1)%ly], [itrial,(jtrial-1)%ly]]:
      # account for the 4J difference if nearest neighbours
      return (change1 + change2 + 4*J)
  # if not nearest neighbours
  else:
      # return dE as sum of energy changes
      return (change1 + change2)

def InitialEnergy():
    E = 0
    for i in range(lx):
        for j in range(ly):
            nn1 = spin[i,j] * spin[i,(j+1)%ly]
            nn2 = spin[i,j] * spin[(i+1)%lx,j]
            nn3 = spin[i,j] * spin[(i-1)%lx,j]
            nn4 = spin[i,j] * spin[i,(j-1)%ly]
            E += (nn1+nn2+nn3+nn4)
    return -J * E/2


# body of the code to be run in the terminal
# sweeps over each position in 50x50 lattice n times (10000 times)
intial_energy = InitialEnergy()
totalenergychange = 0
for n in range(nstep):
    itrial=1
    jtrial=1
    ktrial=1
    ltrial=1
    while [itrial,jtrial] == [ktrial,ltrial]:
        for i in range(lx):
            for j in range(ly):

                #select spin randomly for particle 1 at (i,j) and particle 2 at (k,l)
                itrial=np.random.randint(0,lx)
                jtrial=np.random.randint(0,ly)
                ktrial=np.random.randint(0,lx)
                ltrial=np.random.randint(0,ly)
            # get energy change from Kawasaki dynamics
                if method == 'Kawasaki':
                #select spin randomly for particle 2 at (k,l)
                #ktrial=np.random.randint(0,lx)
                #ltrial=np.random.randint(0,ly)
                #if spin of i,j does not equal k,l then do not enter loop (swapping identical spins will not affect energy)
                #if spin[itrial,jtrial] == spin[ktrial,ltrial]:
                    #continue
                    energy_change = Kawasaki()
                # if the metropolis algorithm gives True: flip the spin
                    if metropolis(energy_change):
                        spin[itrial, jtrial] *= -1
                        spin[ktrial, ltrial] *= -1
                        totalenergychange+=energy_change

                if method == 'Glauber':
                    energy_change = Glauber()
                    if metropolis(energy_change):
                        spin[itrial, jtrial] *= -1
                        totalenergychange+=energy_change


    if (n%10 == 0):
        im=plt.imshow(spin, animated=True, cmap='cool', vmin=-1, vmax=1)
        plt.draw()
        plt.pause(0.01)

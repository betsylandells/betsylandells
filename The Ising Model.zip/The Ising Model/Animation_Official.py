import numpy as np
import matplotlib.pyplot as plt
import random

#get inputs of dimensions and temperature from user
ly = int(input("Number of columns: "))
lx = int(input("Number of rows: "))
T = float(input("Temp of system: "))
#define constants
J = 1
kb = 1
dynamics = input("Dynamics (Glauber/Kawasaki) :")
nstep=10000

#spin = beascp1.initialise_lattice(lx, ly)
#make random lattice
spin=np.zeros((lx,ly),dtype=float)
for i in range(lx):
    for j in range(ly):
        r=random.random()
        if(r<0.5): spin[i,j]=-1
        if(r>=0.5): spin[i,j]=1


def energy_change(spin, i, j, lx, ly):
    nn1 =  spin[i, (j+1)%ly]
    nn2 = spin[(i+1)%lx, j]
    nn3 = spin[(i-1)%lx, j]
    nn4 = spin[i, (j-1)%ly]
    sum_nn = nn1 + nn2 + nn3 + nn4
    dE = 2 * (J * spin[i,j] * sum_nn)
    return dE


def glauber(spin, itrial, jtrial, lx, ly):
    return energy_change(spin, itrial, jtrial, lx, ly)

def kawasaki(spin, i, j, k ,l, lx, ly):
    if [i, j] == [k+1, l] or [i, j] == [k-1, l] or [i, j] == [k, l-1] or [i, j] ==[k, l+1]:
        change1 = energy_change(spin, i, j, lx, ly)
        change2 = energy_change(spin, k, l, lx, ly)
        dE = change1 + change2 + 4*J
        return dE
    else:
        change1 = energy_change(spin, i, j, lx, ly)
        change2 = energy_change(spin, k, l, lx, ly)
        dE = change1 + change2
        return dE

def metropolis(dE, T):
    if dE <= 0:
        return True
    else:
        p = min(1, np.exp(-dE/(kb*T)))
        r = np.random.uniform(0,1)
        if r <= p:
            return True
        else:
            return False

def Magnetisation(spin):
    M = np.sum(spin)
    return M

#do sweeps by looping over lattice
for n in range(nstep):
    for i in range(lx):
        for j in range(ly):

#select spin randomly
            itrial=np.random.randint(0,lx)
            jtrial=np.random.randint(0,ly)
            ktrial=np.random.randint(0,ly)
            ltrial=np.random.randint(0,ly)
            spin_new=-spin[itrial,jtrial]
            spin_new2 = -spin[ktrial, ltrial]
            if dynamics == 'Glauber':
                deltaE = glauber(spin, itrial, jtrial, lx, ly)
                if metropolis(deltaE, T):
                    spin[itrial, jtrial] *= -1
            elif dynamics == "Kawasaki":
                deltaE = kawasaki(spin, itrial, jtrial, ktrial, ltrial, lx, ly)
                if metropolis(deltaE, T):
                    spin[itrial, jtrial] *= -1
                    spin[ktrial, ltrial] *= -1
            else:
                print('Unknown system')
                exit()

    #Magnetisation(spin)
    if (n%10 ==0):
        im=plt.imshow(spin, cmap = 'cool', animated=True, vmin = -1, vmax = 1)
        plt.draw()
        plt.pause(0.0001)
